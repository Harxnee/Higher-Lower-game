from art import logo
from art import vs
import random
print(logo)
from game_data import data

def game():
  flag = 1
  score = 0
  while flag:
    A=random.randint(0,len(data))
    B=random.randint(0,len(data))
    print("Compare A: ", data[A]['name'], " , A", data[A]['description'], "from",  data[A]['country'])
    print(vs)
    print("Against B: ", data[B]['name'], " , A", data[B]['description'], "from",  data[B]['country'])
    choice=input("Who has more followers? Type A or B: ")
    if data[A]['follower_count'] > data[B]['follower_count'] and choice == 'A':
      flag=1
      score += 1
      
    elif data[B]['follower_count'] > data[A]['follower_count'] and choice == 'B':
      flag = 1
      score +=1
    
    else:
      flag = 0
      print("Your score is: ",score)

game()
